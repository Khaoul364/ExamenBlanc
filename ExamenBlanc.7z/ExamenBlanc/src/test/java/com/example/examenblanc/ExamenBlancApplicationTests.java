package com.example.examenblanc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamenBlancApplicationTests {

    @Test
    void contextLoads() {
    }

}
