package com.example.examenblanc.services;

import com.example.examenblanc.entities.CoursClassroom;
import com.example.examenblanc.repository.CoursClassroomRepository;
import lombok.AllArgsConstructor;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor

public class CoursClassroomService implements ICoursClassroomService{
    CoursClassroomRepository coursClassroomRepository;

    @Override
    public List<CoursClassroom> retrieveCoursClassrooms() {
        return coursClassroomRepository.findAll();
    }

    @Override
    public CoursClassroom retrieveById(Long id) {
        return coursClassroomRepository.findById(id).orElse(null);
    }

    @Override
    public CoursClassroom saveCoursClassroom(CoursClassroom CC) {
        return coursClassroomRepository (CoursClassroom CC);
    }

    @Override
    public CoursClassroom updateCoursClassroom(CoursClassroom CC) {
        return coursClassroomRepository.save(CC);
    }

    @Override
    public void deleteCoursClassroom(Long id) {
        coursClassroomRepository.deleteById(id);

        @Scheduled  ( fixedRate = 60000)
        public void fixedRateMethod() {
            System.out.println("Method with fixed Rate");
            List <CoursClassroom> coursClassrooms=
                    coursClassroomRepository.findAll();
            for (CoursClassroom CC : coursClassrooms) {
                System.out.println( CC.toString());

            }


        }
}
