package com.example.examenblanc.repository;

import com.example.examenblanc.entities.Utilisateur;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UtilisateursRepository extends JpaRepository<Utilisateur, Long> {
}
