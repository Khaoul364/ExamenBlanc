package com.example.examenblanc.entities;

public enum Niveau {
    PREMIERE, DEUXIEME, TROISIEME, QUATRIEME, CINQUIEME;
}
