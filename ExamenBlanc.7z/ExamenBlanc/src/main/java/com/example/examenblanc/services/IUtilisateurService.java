package com.example.examenblanc.services;

import com.example.examenblanc.entities.Utilisateur;

import java.util.List;


public interface IUtilisateurService {
    List<Utilisateur> retrieveUtilisateurs();
    Utilisateur retrieveById(Long id);
    Utilisateur saveUtilisateur(Utilisateur U);
    Utilisateur updateUtilisateur(Utilisateur U);
    void deleteUtilisateur(Long id);

}
