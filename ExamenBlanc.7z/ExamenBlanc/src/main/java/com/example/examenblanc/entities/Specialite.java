package com.example.examenblanc.entities;

public enum Specialite {
    INFORMATION, GENIECIVIL,
    AGRICULTURE;
}
