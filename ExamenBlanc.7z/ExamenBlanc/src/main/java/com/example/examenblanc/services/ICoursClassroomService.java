package com.example.examenblanc.services;

import com.example.examenblanc.entities.CoursClassroom;

import java.util.List;

public interface ICoursClassroomService {
    List <CoursClassroom> retrieveCoursClassrooms();
    CoursClassroom retrieveById (Long id);
    CoursClassroom saveCoursClassroom (CoursClassroom CC);
    CoursClassroom updateCoursClassroom (CoursClassroom CC);
    void deleteCoursClassroom (Long id);
}
