package com.example.examenblanc.entities;

import jakarta.persistence.*;
import lombok.*;

import java.io.Serializable;

@Entity
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CoursClassroom implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long idCours;
    Specialite specialite;
    String nom;
    Integer nbHeures;
    Boolean archive;

    @ManyToOne
    public Classe classes;




}
