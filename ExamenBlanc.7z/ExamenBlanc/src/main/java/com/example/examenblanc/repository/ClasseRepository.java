package com.example.examenblanc.repository;

import com.example.examenblanc.entities.Classe;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClasseRepository extends JpaRepository<Classe, Long> {
}
