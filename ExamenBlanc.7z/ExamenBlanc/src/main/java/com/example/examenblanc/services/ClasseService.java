package com.example.examenblanc.services;

import com.example.examenblanc.entities.Classe;
import com.example.examenblanc.repository.ClasseRepository;

import java.util.List;

public class ClasseService implements IClasseService {
   ClasseRepository  classeRepository;

   @Override
   public List<Classe> retrieveClasse() {
      return null;
   }

   @Override
   public Classe retrieveById(Long id) {
      return null;
   }

   @Override
   public Classe saveClasse(Classe c) {
      return null;
   }

   @Override
   public Classe updateClasse(Classe c) {
      return null;
   }

   @Override
   public void deleteClasse(Long id) {

   }
}
