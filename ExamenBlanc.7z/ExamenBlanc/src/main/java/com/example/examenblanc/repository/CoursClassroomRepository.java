package com.example.examenblanc.repository;

import com.example.examenblanc.entities.CoursClassroom;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CoursClassroomRepository extends JpaRepository<CoursClassroom, Long> {
}
