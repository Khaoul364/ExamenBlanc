package com.example.examenblanc.services;

import com.example.examenblanc.entities.Classe;

import java.util.List;

public interface IClasseService {
    List<Classe> retrieveClasse();
    Classe retrieveById(Long id);
    Classe saveClasse(Classe c);
    Classe updateClasse(Classe c);
    void deleteClasse(Long id);

}
