package com.example.examenblanc.entities;

import jakarta.persistence.*;
import lombok.*;

import java.io.Serializable;
import java.util.Set;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Classe implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long codeClasse;
    String titre;
    Niveau niveau;

    @OneToMany(mappedBy = "classe")
    public Set<Utilisateur> utilisaeurs;

    @OneToMany(mappedBy = "classe")
    public Set<CoursClassroom> coursclassrooms;
}