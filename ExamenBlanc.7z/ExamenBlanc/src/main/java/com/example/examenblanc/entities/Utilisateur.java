package com.example.examenblanc.entities;

import jakarta.persistence.*;
import lombok.*;


import java.io.Serializable;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Utilisateur implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long idUtilisateur;
    String prenom;
    String nom;
    String password;

    @ManyToOne
    public Classe classes;
}
