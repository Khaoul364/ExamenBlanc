package com.example.examenblanc.services;

import com.example.examenblanc.entities.Utilisateur;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@AllArgsConstructor
public class UtilisateurService implements IUtilisateurService{
    @Override
    public List<Utilisateur> retrieveUtilisateurs() {
        return null;
    }

    @Override
    public Utilisateur retrieveById(Long id) {
        return null;
    }

    @Override
    public Utilisateur saveUtilisateur(Utilisateur U) {
        return null;
    }

    @Override
    public Utilisateur updateUtilisateur(Utilisateur U) {
        return null;
    }

    @Override
    public void deleteUtilisateur(Long id) {

    }
}
